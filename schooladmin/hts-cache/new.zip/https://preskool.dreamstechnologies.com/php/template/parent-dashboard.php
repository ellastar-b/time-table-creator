<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<meta name="description" content="Preskool - Bootstrap Admin Template">
<meta name="keywords" content="admin, estimates, bootstrap, business, html5, responsive, Projects">
<meta name="author" content="Dreams technologies - Bootstrap Admin Template">
<meta name="robots" content="noindex, nofollow">
<title>Preskool Admin Template</title>

<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<link rel="stylesheet" href="assets/plugins/icons/feather/feather.css">

<link rel="stylesheet" href="assets/css/animate.css">

<link rel="stylesheet" href="assets/css/dataTables.bootstrap5.min.css">

<link rel="stylesheet" href="assets/plugins/tabler-icons/tabler-icons.css">

<link rel="stylesheet" href="assets/plugins/daterangepicker/daterangepicker.css">

<link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css">

<link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">

<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

<link rel="stylesheet" href="assets/plugins/owlcarousel/owl.carousel.min.css">
<link rel="stylesheet" href="assets/plugins/owlcarousel/owl.theme.default.min.css">

<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div id="global-loader">
<div class="page-loader"></div>
</div>

<div class="main-wrapper">

<div class="header">

<div class="header-left active">
<a href="index.php" class="logo logo-normal">
<img src="assets/img/logo.svg" alt="Logo">
</a>
<a href="index.php" class="logo-small">
<img src="assets/img/logo-small.svg" alt="Logo">
</a>
<a href="index.php" class="dark-logo">
<img src="assets/img/logo-dark.svg" alt="Logo">
</a>
<a id="toggle_btn" href="javascript:void(0);">
<i class="ti ti-menu-deep"></i>
</a>
</div>

<a id="mobile_btn" class="mobile_btn" href="#sidebar">
<span class="bar-icon">
<span></span>
<span></span>
<span></span>
</span>
</a>
<div class="header-user">
<div class="nav user-menu">

<div class="nav-item nav-search-inputs me-auto">
<div class="top-nav-search">
<a href="javascript:void(0);" class="responsive-search">
<i class="fa fa-search"></i>
</a>
<form action="#" class="dropdown">
<div class="searchinputs" id="dropdownMenuClickable">
<input type="text" placeholder="Search">
<div class="search-addon">
<button type="submit"><i class="ti ti-command"></i></button>
</div>
</div>
</form>
</div>
</div>

<div class="d-flex align-items-center">
<div class="dropdown me-2">
<a href="#" class="btn btn-outline-light fw-normal bg-white d-flex align-items-center p-2" data-bs-toggle="dropdown" aria-expanded="false">
<i class="ti ti-calendar-due me-1"></i>Academic Year : 2024 / 2025
</a>
<div class="dropdown-menu dropdown-menu-right">
<a href="javascript:void(0);" class="dropdown-item d-flex align-items-center">
Academic Year : 2023 / 2024
</a>
<a href="javascript:void(0);" class="dropdown-item d-flex align-items-center">
Academic Year : 2022 / 2023
</a>
<a href="javascript:void(0);" class="dropdown-item d-flex align-items-center">
Academic Year : 2021 / 2022
</a>
</div>
</div>
<div class="pe-1 ms-1">
<div class="dropdown">
<a href="#" class="btn btn-outline-light bg-white btn-icon d-flex align-items-center me-1 p-2" data-bs-toggle="dropdown" aria-expanded="false">
<img src="assets/img/flags/us.png" alt="Language" class="img-fluid rounded-pill">
</a>
<div class="dropdown-menu dropdown-menu-right">
<a href="javascript:void(0);" class="dropdown-item active d-flex align-items-center">
<img class="me-2 rounded-pill" src="assets/img/flags/us.png" alt="Img" height="22" width="22"> English
</a>
<a href="javascript:void(0);" class="dropdown-item d-flex align-items-center">
<img class="me-2 rounded-pill" src="assets/img/flags/fr.png" alt="Img" height="22" width="22"> French
</a>
<a href="javascript:void(0);" class="dropdown-item d-flex align-items-center">
<img class="me-2 rounded-pill" src="assets/img/flags/es.png" alt="Img" height="22" width="22"> Spanish
</a>
<a href="javascript:void(0);" class="dropdown-item d-flex align-items-center">
<img class="me-2 rounded-pill" src="assets/img/flags/de.png" alt="Img" height="22" width="22"> German
</a>
</div>
</div>
</div>
<div class="pe-1">
<div class="dropdown">
<a href="#" class="btn btn-outline-light bg-white btn-icon me-1" data-bs-toggle="dropdown" aria-expanded="false">
<i class="ti ti-square-rounded-plus"></i>
</a>
<div class="dropdown-menu dropdown-menu-right border shadow-sm dropdown-md">
<div class="p-3 border-bottom">
<h5>Add New</h5>
</div>
<div class="p-3 pb-0">
<div class="row gx-2">
<div class="col-6">
<a href="add-student.php" class="d-block bg-primary-transparent ronded p-2 text-center mb-3 class-hover">
<div class="avatar avatar-lg mb-2">
<span class="d-inline-flex align-items-center justify-content-center w-100 h-100 bg-primary rounded-circle"><i class="ti ti-school"></i></span>
</div>
<p class="text-dark">Students</p>
</a>
</div>
<div class="col-6">
<a href="add-teacher.php" class="d-block bg-success-transparent ronded p-2 text-center mb-3 class-hover">
<div class="avatar avatar-lg mb-2">
<span class="d-inline-flex align-items-center justify-content-center w-100 h-100 bg-success rounded-circle"><i class="ti ti-users"></i></span>
</div>
<p class="text-dark">Teachers</p>
</a>
</div>
<div class="col-6">
<a href="add-staff.php" class="d-block bg-warning-transparent ronded p-2 text-center mb-3 class-hover">
<div class="avatar avatar-lg rounded-circle mb-2">
<span class="d-inline-flex align-items-center justify-content-center w-100 h-100 bg-warning rounded-circle"><i class="ti ti-users-group"></i></span>
</div>
<p class="text-dark">Staffs</p>
</a>
</div>
<div class="col-6">
<a href="add-invoice.php" class="d-block bg-info-transparent ronded p-2 text-center mb-3 class-hover">
<div class="avatar avatar-lg mb-2">
<span class="d-inline-flex align-items-center justify-content-center w-100 h-100 bg-info rounded-circle"><i class="ti ti-license"></i></span>
</div>
<p class="text-dark">Invoice</p>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="pe-1">
<a href="#" id="dark-mode-toggle" class="dark-mode-toggle activate btn btn-outline-light bg-white btn-icon me-1">
<i class="ti ti-moon"></i>
</a>
<a href="#" id="light-mode-toggle" class="dark-mode-toggle btn btn-outline-light bg-white btn-icon me-1">
<i class="ti ti-brightness-up"></i>
</a>
</div>
<div class="pe-1" id="notification_item">
<a href="#" class="btn btn-outline-light bg-white btn-icon position-relative me-1" id="notification_popup">
<i class="ti ti-bell"></i>
<span class="notification-status-dot"></span>
</a>
<div class="dropdown-menu dropdown-menu-end notification-dropdown p-4">
<div class="d-flex align-items-center justify-content-between border-bottom p-0 pb-3 mb-3">
<h4 class="notification-title">Notifications (2)</h4>
<div class="d-flex align-items-center">
<a href="#" class="text-primary fs-15 me-3 lh-1">Mark all as read</a>
<div class="dropdown">
<a href="javascript:void(0);" class="bg-white dropdown-toggle" data-bs-toggle="dropdown"><i class="ti ti-calendar-due me-1"></i>Today
</a>
<ul class="dropdown-menu mt-2 p-3">
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
This Week
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Last Week
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Last Week
</a>
</li>
</ul>
</div>
</div>
</div>
<div class="noti-content">
<div class="d-flex flex-column">
<div class="border-bottom mb-3 pb-3">
<a href="activities.php">
<div class="d-flex">
<span class="avatar avatar-lg me-2 flex-shrink-0">
<img src="assets/img/profiles/avatar-27.jpg" alt="Profile">
</span>
<div class="flex-grow-1">
<p class="mb-1"><span class="text-dark fw-semibold">Shawn</span> performance in Math is
below the threshold.</p>
<span>Just Now</span>
</div>
</div>
</a>
</div>
<div class="border-bottom mb-3 pb-3">
<a href="activities.php" class="pb-0">
<div class="d-flex">
<span class="avatar avatar-lg me-2 flex-shrink-0">
<img src="assets/img/profiles/avatar-23.jpg" alt="Profile">
</span>
<div class="flex-grow-1">
<p class="mb-1"><span class="text-dark fw-semibold">Sylvia</span> added appointment on
02:00 PM</p>
<span>10 mins ago</span>
<div class="d-flex justify-content-start align-items-center mt-1">
<span class="btn btn-light btn-sm me-2">Deny</span>
<span class="btn btn-primary btn-sm">Approve</span>
</div>
</div>
</div>
</a>
</div>
<div class="border-bottom mb-3 pb-3">
<a href="activities.php">
<div class="d-flex">
<span class="avatar avatar-lg me-2 flex-shrink-0">
<img src="assets/img/profiles/avatar-25.jpg" alt="Profile">
</span>
<div class="flex-grow-1">
<p class="mb-1">New student record <span class="text-dark fw-semibold"> George</span> is
created by <span class="text-dark fw-semibold"> Teressa</span></p>
<span>2 hrs ago</span>
</div>
</div>
</a>
</div>
<div class="border-0 mb-3 pb-0">
<a href="activities.php">
<div class="d-flex">
<span class="avatar avatar-lg me-2 flex-shrink-0">
<img src="assets/img/profiles/avatar-01.jpg" alt="Profile">
</span>
<div class="flex-grow-1">
<p class="mb-1">A new teacher record for <span class="text-dark fw-semibold">Elisa</span>
</p>
<span>09:45 AM</span>
</div>
</div>
</a>
</div>
</div>
</div>
<div class="d-flex p-0">
<a href="#" class="btn btn-light w-100 me-2">Cancel</a>
<a href="activities.php" class="btn btn-primary w-100">View All</a>
</div>
</div>
</div>
<div class="pe-1">
<a href="chat.php" class="btn btn-outline-light bg-white btn-icon position-relative me-1">
<i class="ti ti-brand-hipchat"></i>
<span class="chat-status-dot"></span>
</a>
</div>
<div class="pe-1">
<a href="#" class="btn btn-outline-light bg-white btn-icon me-1">
<i class="ti ti-chart-bar"></i>
</a>
</div>
<div class="pe-1">
<a href="#" class="btn btn-outline-light bg-white btn-icon me-1" id="btnFullscreen">
<i class="ti ti-maximize"></i>
</a>
</div>
<div class="dropdown ms-1">
<a href="javascript:void(0);" class="dropdown-toggle d-flex align-items-center" data-bs-toggle="dropdown">
<span class="avatar avatar-md rounded">
<img src="assets/img/profiles/avatar-27.jpg" alt="Img" class="img-fluid">
</span>
</a>
<div class="dropdown-menu">
<div class="d-block">
<div class="d-flex align-items-center p-2">
<span class="avatar avatar-md me-2 online avatar-rounded">
<img src="assets/img/profiles/avatar-27.jpg" alt="img">
</span>
<div>
<h6 class>Kevin Larry</h6>
<p class="text-primary mb-0">Administrator</p>
</div>
</div>
<hr class="m-0">
<a class="dropdown-item d-inline-flex align-items-center p-2" href="profile.php"> <i class="ti ti-user-circle me-2"></i>My Profile</a>
<a class="dropdown-item d-inline-flex align-items-center p-2" href="profile-settings.php"><i class="ti ti-settings me-2"></i>Settings</a>
<hr class="m-0">
<a class="dropdown-item d-inline-flex align-items-center p-2" href="login.php"><i class="ti ti-login me-2"></i>Logout</a>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="dropdown mobile-user-menu">
<a href="javascript:void(0);" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
<div class="dropdown-menu dropdown-menu-end">
<a class="dropdown-item" href="profile.php">My Profile</a>
<a class="dropdown-item" href="profile-settings.php">Settings</a>
<a class="dropdown-item" href="login.php">Logout</a>
</div>
</div>

</div>


<div class="sidebar" id="sidebar">
<div class="sidebar-inner slimscroll">
<div id="sidebar-menu" class="sidebar-menu">
<ul>
<li>
<a href="javascript:void(0);" class="d-flex align-items-center border bg-white rounded p-2 mb-4">
<img src="assets/img/icons/global-img.svg" class="avatar avatar-md img-fluid rounded" alt="Profile">
<span class="text-dark ms-2 fw-normal">Global International</span>
</a>
</li>
</ul>
<ul>
<li>
<h6 class="submenu-hdr"><span>Main</span></h6>
<ul>
<li class="submenu">
<a class="active subdrop" href="javascript:void(0);"><i class="ti ti-layout-dashboard"></i><span>Dashboard</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="index.php">Admin Dashboard</a></li>
<li><a class href="teacher-dashboard.php">Teacher Dashboard</a></li>
<li><a class href="student-dashboard.php">Student Dashboard</a></li>
<li><a class="active" href="parent-dashboard.php">Parent Dashboard</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-layout-list"></i><span>Application</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="chat.php">Chat</a></li>
<li><a class href="call.php">Call</a></li>
<li><a class href="calendar.php">Calendar</a></li>
<li><a class href="email.php">Email</a></li>
<li><a class href="todo.php">To Do</a></li>
<li><a class href="notes.php">Notes</a></li>
<li><a class href="file-manager.php">File Manager</a></li>
</ul>
</li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Layout</span></h6>
<ul>
<li class><a href="layout-default.php"><i class="ti ti-layout-sidebar"></i><span>Default </span></a></li>
<li class><a href="layout-mini.php"><i class="ti ti-layout-align-left"></i><span>Mini</span></a></li>
<li class><a href="layout-rtl.php"><i class="ti ti-text-direction-rtl"></i><span>RTL</span></a></li>
<li class><a href="layout-box.php"><i class="ti ti-layout-distribute-vertical"></i><span>Box</span></a></li>
<li class><a href="layout-dark.php"><i class="ti ti-moon"></i><span>Dark</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Peoples</span></h6>
<ul>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-school"></i><span>Students</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="student-grid.php">All Students</a></li>
<li><a class href="students.php">Student List</a></li>
<li><a class href="student-details.php">Student Details</a></li>
<li><a class href="student-promotion.php">Student Promotion</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-user-bolt"></i><span>Parents</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="parent-grid.php">All Parents</a></li>
<li><a class href="parents.php">Parent List</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-user-shield"></i><span>Guardians</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="guardian-grid.php">All Guardians</a></li>
<li><a class href="guardians.php">Guardian List</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-users"></i><span>Teachers</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="teacher-grid.php">All Teachers</a></li>
<li><a class href="teachers.php">Teacher List</a></li>
<li><a class href="teacher-details.php">Teacher Details</a></li>
<li><a class href="routine-teachers.php">Routine</a></li>
</ul>
</li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Academic</span></h6>
<ul>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-school-bell"></i><span>Classes</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="classes.php">All Classes</a></li>
<li><a class href="schedule-classes.php">Schedule</a></li>
</ul>
</li>
<li class><a href="class-room.php"><i class="ti ti-building"></i><span>Class Room</span></a></li>
<li class><a href="class-routine.php"><i class="ti ti-bell-school"></i><span>Class Routine</span></a></li>
<li class><a href="class-section.php"><i class="ti ti-square-rotated-forbid-2"></i><span>Section</span></a></li>
<li class><a href="class-subject.php"><i class="ti ti-book"></i><span>Subject</span></a></li>
<li class><a href="class-syllabus.php"><i class="ti ti-book-upload"></i><span>Syllabus</span></a></li>
<li class><a href="class-time-table.php"><i class="ti ti-table"></i><span>Time Table</span></a></li>
<li class><a href="class-home-work.php"><i class="ti ti-license"></i><span>Home Work</span></a></li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-hexagonal-prism-plus"></i><span>Examinations</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="exam.php">Exam</a></li>
<li><a class href="exam-schedule.php">Exam Schedule</a></li>
<li><a class href="grade.php">Grade</a></li>
<li><a class href="exam-attendance.php">Exam Attendance</a></li>
<li><a class href="exam-results.php">Exam Results</a></li>
</ul>
</li>
<li class><a href="academic-reasons.php"><i class="ti ti-lifebuoy"></i><span>Reasons</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Management</span></h6>
<ul>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-report-money"></i><span>Fees Collection</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="fees-group.php">Fees Group</a></li>
<li><a class href="fees-type.php">Fees Type</a></li>
<li><a class href="fees-master.php">Fees Master</a></li>
<li><a class href="fees-assign.php">Fees Assign</a></li>
<li><a class href="collect-fees.php">Collect Fees</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-notebook"></i><span>Library</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="library-members.php">Library Members</a></li>
<li><a class href="library-books.php">Books</a></li>
<li><a class href="library-issue-book.php">Issue Book</a></li>
<li><a class href="library-return.php">Return</a></li>
</ul>
</li>
<li class><a href="sports.php"><i class="ti ti-run"></i><span>Sports</span></a></li>
<li class><a href="players.php"><i class="ti ti-play-football"></i><span>Players</span></a></li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-building-fortress"></i><span>Hostel</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="hostel-list.php">Hostel List</a></li>
<li><a class href="hostel-rooms.php">Hostel Rooms</a></li>
<li><a class href="hostel-room-type.php">Room Type</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-bus"></i><span>Transport</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="transport-routes.php">Routes</a></li>
<li><a class href="transport-pickup-points.php">Pickup Points</a></li>
<li><a class href="transport-vehicle-drivers.php">Vehicle Drivers</a></li>
<li><a class href="transport-vehicle.php">Vehicle</a></li>
<li><a class href="transport-assign-vehicle.php">Assign Vehicle</a></li>
</ul>
</li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>HRM</span></h6>
<ul>
<li class><a href="staffs.php"><i class="ti ti-users-group"></i><span>Staffs</span></a></li>
<li class><a href="departments.php"><i class="ti ti-layout-distribute-horizontal"></i><span>Departments</span></a></li>
<li class><a href="designation.php"><i class="ti ti-user-exclamation"></i><span>Designation</span></a></li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-calendar-share"></i><span>Attendance</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="student-attendance.php">Student Attendance</a></li>
<li><a class href="teacher-attendance.php">Teacher Attendance</a></li>
<li><a class href="staff-attendance.php">Staff Attendance</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-calendar-stats"></i><span>Leaves</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="list-leaves.php">List of leaves</a></li>
<li><a class href="approve-request.php">Approve Request</a></li>
</ul>
</li>
<li class><a href="holidays.php"><i class="ti ti-briefcase"></i><span>Holidays</span></a></li>
<li class><a href="payroll.php"><i class="ti ti-moneybag"></i><span>Payroll</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Finance & Accounts</span></h6>
<ul>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-swipe"></i><span>Accounts</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="expenses.php">Expenses</a></li>
<li><a class href="expenses-category.php">Expense Category</a></li>
<li><a class href="accounts-income.php">Income</a></li>
<li><a class href="accounts-invoices.php">Invoices</a></li>
<li><a class href="invoice.php">Invoice View</a></li>
<li><a class href="accounts-transactions.php">Transactions</a></li>
</ul>
</li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Announcements</span></h6>
<ul>
<li class><a href="notice-board.php"><i class="ti ti-clipboard-data"></i><span>Notice Board</span></a></li>
<li class><a href="events.php"><i class="ti ti-calendar-question"></i><span>Events</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Reports</span></h6>
<ul>
<li class><a href="attendance-report.php"><i class="ti ti-calendar-due"></i><span>Attendance Report</span></a></li>
<li class><a href="class-report.php"><i class="ti ti-graph"></i><span>Class Report</span></a></li>
<li class><a href="student-report.php"><i class="ti ti-chart-infographic"></i><span>Student Report</span></a></li>
<li class><a href="grade-report.php"><i class="ti ti-calendar-x"></i><span>Grade Report</span></a></li>
<li class><a href="leave-report.php"><i class="ti ti-line"></i><span>Leave Report</span></a></li>
<li class><a href="fees-report.php"><i class="ti ti-mask"></i><span>Fees Report</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>User Management</span></h6>
<ul>
<li class><a href="users.php"><i class="ti ti-users-minus"></i><span>Users</span></a></li>
<li class><a href="roles-permission.php"><i class="ti ti-shield-plus"></i><span>Roles & Permissions</span></a></li>
<li class><a href="delete-account.php"><i class="ti ti-user-question"></i><span>Delete Account Request</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Membership</span></h6>
<ul>
<li class><a href="membership-plans.php"><i class="ti ti-user-plus"></i><span>Membership Plans</span></a></li>
<li class><a href="membership-addons.php"><i class="ti ti-cone-plus"></i><span>Membership Addons</span></a></li>
<li class><a href="membership-transactions.php"><i class="ti ti-file-power"></i><span>Transactions</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Content</span></h6>
<ul>
<li class><a href="pages.php"><i class="ti ti-page-break"></i><span>Pages</span></a></li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-brand-blogger"></i><span>Blog</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="blog.php">All Blogs</a></li>
<li><a class href="blog-categories.php">Categories</a></li>
<li><a class href="blog-comments.php">Comments</a></li>
<li><a class href="blog-tags.php">Tags</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-map-pin-search"></i><span>Location</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="countries.php">Countries</a></li>
<li><a class href="states.php">States</a></li>
<li><a class href="cities.php">Cities</a></li>
</ul>
</li>
<li class><a href="testimonials.php"><i class="ti ti-quote"></i><span>Testimonials</span></a></li>
<li class><a href="faq.php"><i class="ti ti-question-mark"></i><span>FAQ</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Support</span></h6>
<ul>
<li class><a href="contact-messages.php"><i class="ti ti-message"></i><span>Contact Messages</span></a></li>
<li class><a href="tickets.php"><i class="ti ti-ticket"></i><span>Tickets</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Pages</span></h6>
<ul>
<li class><a href="profile.php"><i class="ti ti-user"></i><span>Profile</span></a></li>
<li class="submenu">
<a href="javascript:void(0);">
<i class="ti ti-lock-open"></i><span>Authentication</span><span class="menu-arrow"></span>
</a>
<ul>
<li class="submenu submenu-two"><a class href="javascript:void(0);" class>Login<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="login.php">Cover</a></li>
<li><a class href="login-2.php">Illustration</a></li>
<li><a class href="login-3.php">Basic</a></li>
</ul>
</li>
<li class="submenu submenu-two"><a class href="javascript:void(0);" class>Register<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="register.php">Cover</a></li>
<li><a class href="register-2.php">Illustration</a></li>
<li><a class href="register-3.php">Basic</a></li>
</ul>
</li>
<li class="submenu submenu-two"><a class href="javascript:void(0);">Forgot Password<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="forgot-password.php">Cover</a></li>
<li><a class href="forgot-password-2.php">Illustration</a></li>
<li><a class href="forgot-password-3.php">Basic</a></li>
</ul>
</li>
<li class="submenu submenu-two"><a class href="javascript:void(0);">Reset Password<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="reset-password.php">Cover</a></li>
<li><a class href="reset-password-2.php">Illustration</a></li>
<li><a class href="reset-password-3.php">Basic</a></li>
</ul>
</li>
<li class="submenu submenu-two"><a class href="javascript:void(0);">Email Verification<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="email-verification.php">Cover</a></li>
<li><a class href="email-verification-2.php">Illustration</a></li>
<li><a class href="email-verification-3.php">Basic</a></li>
</ul>
</li>
<li class="submenu submenu-two"><a class href="javascript:void(0);">2 Step Verification<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="two-step-verification.php">Cover</a></li>
<li><a class href="two-step-verification-2.php">Illustration</a></li>
<li><a class href="two-step-verification-3.php">Basic</a></li>
</ul>
</li>
<li class><a href="lock-screen.php">Lock Screen</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-error-404"></i><span>Error Pages</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="404-error.php">404 Error</a></li>
<li><a class href="500-error.php">500 Error</a></li>
</ul>
</li>
<li class><a href="blank-page.php"><i class="ti ti-brand-nuxt"></i><span>Blank Page</span></a></li>
<li class><a href="coming-soon.php"><i class="ti ti-file"></i><span>Coming Soon</span></a></li>
<li class><a href="under-maintenance.php"><i class="ti ti-moon-2"></i><span>Under Maintenance</span></a></li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Settings</span></h6>
<ul>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-shield-cog"></i><span>General Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="profile-settings.php">Profile Settings</a></li>
<li><a class href="security-settings.php">Security Settings</a></li>
<li><a class href="notifications-settings.php">Notifications Settings</a></li>
<li><a class href="connected-apps.php">Connected Apps</a></li>
</ul>
</li>

<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-device-laptop"></i><span>Website Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="company-settings.php">Company Settings</a></li>
<li><a class href="localization.php">Localization</a></li>
<li><a class href="prefixes.php">Prefixes</a></li>
<li><a class href="preferences.php">Preferences</a></li>
<li><a class href="social-authentication.php">Social Authentication</a></li>
<li><a class href="language.php">Language</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-apps"></i><span>App Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="invoice-settings.php">Invoice Settings</a></li>
<li><a class href="custom-fields.php">Custom Fields</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-file-symlink"></i><span>System Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="email-settings.php">Email Settings</a></li>
<li><a class href="email-templates.php">Email Templates</a></li>
<li><a class href="sms-settings.php">SMS Settings</a></li>
<li><a class href="otp-settings.php">OTP</a></li>
<li><a class href="gdpr-cookies.php">GDPR Cookies</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-zoom-money"></i><span>Financial Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="payment-gateways.php">Payment Gateways </a></li>
<li><a class href="tax-rates.php">Tax Rates</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-calendar-repeat"></i><span>Academic Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="school-settings.php">School Settings </a></li>
<li><a class href="religion.php">Religion</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-flag-cog"></i><span>Other Settings</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="storage.php">Storage</a></li>
<li><a class href="ban-ip-address.php">Ban IP Address</a></li>
</ul>
</li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>UI Interface</span></h6>
<ul>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-hierarchy-2"></i><span>Base UI</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="ui-alerts.php">Alerts</a></li>
<li><a class href="ui-accordion.php">Accordion</a></li>
<li><a class href="ui-avatar.php">Avatar</a></li>
<li><a class href="ui-badges.php">Badges</a></li>
<li><a class href="ui-borders.php">Border</a></li>
<li><a class href="ui-buttons.php">Buttons</a></li>
<li><a class href="ui-buttons-group.php">Button Group</a></li>
<li><a class href="ui-breadcrumb.php">Breadcrumb</a></li>
<li><a class href="ui-cards.php">Card</a></li>
<li><a class href="ui-carousel.php">Carousel</a></li>
<li><a class href="ui-colors.php">Colors</a></li>
<li><a class href="ui-dropdowns.php">Dropdowns</a></li>
<li><a class href="ui-grid.php">Grid</a></li>
<li><a class href="ui-images.php">Images</a></li>
<li><a class href="ui-lightbox.php">Lightbox</a></li>
<li><a class href="ui-media.php">Media</a></li>
<li><a class href="ui-modals.php">Modals</a></li>
<li><a class href="ui-offcanvas.php">Offcanvas</a></li>
<li><a class href="ui-pagination.php">Pagination</a></li>
<li><a class href="ui-popovers.php">Popovers</a></li>
<li><a class href="ui-progress.php">Progress</a></li>
<li><a class href="ui-placeholders.php">Placeholders</a></li>
<li><a class href="ui-spinner.php">Spinner</a></li>
<li><a class href="ui-sweetalerts.php">Sweet Alerts</a></li>
<li><a class href="ui-nav-tabs.php">Tabs</a></li>
<li><a class href="ui-toasts.php">Toasts</a></li>
<li><a class href="ui-tooltips.php">Tooltips</a></li>
<li><a class href="ui-typography.php">Typography</a></li>
<li><a class href="ui-video.php">Video</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-hierarchy-3"></i><span>Advanced UI</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="ui-ribbon.php">Ribbon</a></li>
<li><a class href="ui-clipboard.php">Clipboard</a></li>
<li><a class href="ui-drag-drop.php">Drag & Drop</a></li>
<li><a class href="ui-rangeslider.php">Range Slider</a></li>
<li><a class href="ui-rating.php">Rating</a></li>
<li><a class href="ui-text-editor.php">Text Editor</a></li>
<li><a class href="ui-counter.php">Counter</a></li>
<li><a class href="ui-scrollbar.php">Scrollbar</a></li>
<li><a class href="ui-stickynote.php">Sticky Note</a></li>
<li><a class href="ui-timeline.php">Timeline</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-chart-line"></i>
<span>Charts</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="chart-apex.php">Apex Charts</a></li>
<li><a class href="chart-c3.php">Chart C3</a></li>
<li><a class href="chart-js.php">Chart Js</a></li>
<li><a class href="chart-morris.php">Morris Charts</a></li>
<li><a class href="chart-flot.php">Flot Charts</a></li>
<li><a class href="chart-peity.php">Peity Charts</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-icons"></i>
<span>Icons</span><span class="menu-arrow"></span>
</a>
<ul>
<li><a class href="icon-fontawesome.php">Fontawesome Icons</a></li>
<li><a class href="icon-feather.php">Feather Icons</a></li>
<li><a class href="icon-ionic.php">Ionic Icons</a></li>
<li><a class href="icon-material.php">Material Icons</a></li>
<li><a class href="icon-pe7.php">Pe7 Icons</a></li>
<li><a class href="icon-simpleline.php">Simpleline Icons</a></li>
<li><a class href="icon-themify.php">Themify Icons</a></li>
<li><a class href="icon-weather.php">Weather Icons</a></li>
<li><a class href="icon-typicon.php">Typicon Icons</a></li>
<li><a class href="icon-flag.php">Flag Icons</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);">
<i class="ti ti-input-search"></i><span>Forms</span><span class="menu-arrow"></span>
</a>
<ul>
<li class="submenu submenu-two">
<a class href="javascript:void(0);">Form Elements<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="form-basic-inputs.php">Basic Inputs</a></li>
<li><a class href="form-checkbox-radios.php">Checkbox & Radios</a></li>
<li><a class href="form-input-groups.php">Input Groups</a></li>
<li><a class href="form-grid-gutters.php">Grid & Gutters</a></li>
<li><a class href="form-select.php">Form Select</a></li>
<li><a class href="form-mask.php">Input Masks</a></li>
<li><a class href="form-fileupload.php">File Uploads</a></li>
</ul>
</li>
<li class="submenu submenu-two">
<a class href="javascript:void(0);">Layouts<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a class href="form-horizontal.php">Horizontal Form</a></li>
<li><a class href="form-vertical.php">Vertical Form</a></li>
<li><a class href="form-floating-labels.php">Floating Labels</a></li>
</ul>
</li>
<li><a class href="form-validation.php">Form Validation</a></li>
<li><a class href="form-select2.php">Select2</a></li>
<li><a class href="form-wizard.php">Form Wizard</a></li>
</ul>
</li>
<li class="submenu">
<a class href="javascript:void(0);"><i class="ti ti-table-plus"></i><span>Tables</span><span class="menu-arrow"></span></a>
<ul>
<li><a class href="tables-basic.php">Basic Tables </a></li>
<li><a class href="data-tables.php">Data Table </a></li>
</ul>
</li>
</ul>
</li>
<li>
<h6 class="submenu-hdr"><span>Help</span></h6>
<ul>
<li><a href="https://preschool.dreamstechnologies.com/documentation/index.php"><i class="ti ti-file-text"></i><span>Documentation</span></a></li>
<li><a href="https://preschool.dreamstechnologies.com/documentation/changelog.php"><i class="ti ti-exchange"></i><span>Changelog</span><span class="badge badge-primary badge-xs text-white fs-10 ms-auto">v1.8.3</span></a></li>
<li class="submenu">
<a href="javascript:void(0);"><i class="ti ti-menu-2"></i><span>Multi Level</span><span class="menu-arrow"></span></a>
<ul>
<li><a href="javascript:void(0);">Multilevel 1</a></li>
<li class="submenu submenu-two"><a href="javascript:void(0);">Multilevel 2<span class="menu-arrow inside-submenu"></span></a>
<ul>
<li><a href="javascript:void(0);">Multilevel 2.1</a></li>
<li class="submenu submenu-two submenu-three"><a href="javascript:void(0);">Multilevel 2.2<span class="menu-arrow inside-submenu inside-submenu-two"></span></a>
<ul>
<li><a href="javascript:void(0);">Multilevel 2.2.1</a></li>
<li><a href="javascript:void(0);">Multilevel 2.2.2</a></li>
</ul>
</li>
</ul>
</li>
<li><a href="javascript:void(0);">Multilevel 3</a></li>
</ul>
</li>
</ul>
</li>
</ul>
</div>
</div>
</div>


<div class="page-wrapper">
<div class="content">

<div class="d-md-flex d-block align-items-center justify-content-between mb-3">
<div class="my-auto mb-2">
<h3 class="page-title mb-1">Parent Dashboard</h3>
<nav>
<ol class="breadcrumb mb-0">
<li class="breadcrumb-item">
<a href="index.php">Dashboard</a>
</li>
<li class="breadcrumb-item active" aria-current="page">Parent Dashboard</li>
</ol>
</nav>
</div>
<div class="dash-select-student d-flex align-items-center mb-2">
<h6 class="mb-0">Select Student</h6>
<div class="student-active d-flex align-items-center ms-2">
<a href="#" class="avatar avatar-lg p-1 me-2 active">
<img src="assets/img/students/student-01.jpg" alt="Profile">
</a>
<a href="#" class="avatar avatar-lg p-1">
<img src="assets/img/students/student-02.jpg" alt="Profile">
</a>
</div>
</div>
</div>

<div class="row">

<div class="col-xxl-5 col-xl-12 d-flex">
<div class="card bg-dark position-relative flex-fill">
<div class="card-body">
<div class="d-flex align-items-center row-gap-3">
<div class="avatar avatar-xxl rounded flex-shrink-0 me-3">
<img src="assets/img/parents/parent-01.jpg" alt="Img">
</div>
<div class="d-block">
<span class="badge bg-transparent-primary text-primary mb-1">#P124556</span>
<h4 class="text-truncate text-white mb-1">Thomas Bown</h4>
<div class="d-flex align-items-center flex-wrap row-gap-2 class-info">
<span>Added On : 25 Mar 2024</span>
<span>Child : Janet</span>
</div>
</div>
</div>
<div class="student-card-bg">
<img src="assets/img/bg/circle-shape.png" alt="Bg">
<img src="assets/img/bg/shape-02.png" alt="Bg">
<img src="assets/img/bg/shape-04.png" alt="Bg">
<img src="assets/img/bg/blue-polygon.png" alt="Bg">
</div>
</div>
</div>
</div>


<div class="col-xxl-7 d-flex">
<div class="row flex-fill">
<div class="col-xl-4 d-flex flex-column">
<div class="d-flex bg-white border rounded flex-wrap justify-content-between align-items-center p-3 row-gap-2 mb-2 animate-card">
<div class="d-flex align-items-center">
<span class="avatar avatar-sm bg-light-500 me-2 rounded"><i class="ti ti-calendar-event text-dark fs-16"></i></span>
<h6>Apply Leave</h6>
</div>
<a href="student-leaves.php" class="badge rounded-circle arrow d-flex align-items-center justify-content-center"><i class="ti ti-chevron-right fs-14"></i></a>
</div>
<div class="d-flex bg-white border rounded flex-wrap justify-content-between align-items-center p-3 row-gap-2 mb-4 animate-card">
<div class="d-flex align-items-center">
<span class="avatar avatar-sm bg-light-500 me-2 rounded"><i class="ti ti-message-up text-dark fs-16"></i></span>
<h6>Raise a Request</h6>
</div>
<a href="approve-request.php" class="badge rounded-circle arrow d-flex align-items-center justify-content-center"><i class="ti ti-chevron-right fs-14"></i></a>
</div>
</div>
<div class="col-xl-4 col-md-6">
<div class="card bg-success-transparent border-3 border-white text-center p-3">
<span class="avatar avatar-sm rounded bg-success mx-auto mb-3">
<i class="ti ti-calendar-share fs-15"></i>
</span>
<h6 class="mb-2">Medical Leaves (10)</h6>
<div class="d-flex align-items-center justify-content-between text-default">
<p class="border-end mb-0">Used : 05</p>
<p>Available : 10</p>
</div>
</div>
</div>
<div class="col-xl-4 col-md-6">
<div class="card bg-primary-transparent border-3 border-white text-center p-3">
<span class="avatar avatar-sm rounded bg-primary mx-auto mb-3">
<i class="ti ti-hexagonal-prism-plus fs-15"></i>
</span>
<h6 class="mb-2">Casual Leaves (12)</h6>
<div class="d-flex align-items-center justify-content-between text-default">
<p class="border-end mb-0">Used : 05</p>
<p>Available : 10</p>
</div>
</div>
</div>
</div>
</div>

</div>
<div class="row">

<div class="col-xxl-4 col-xl-6 d-flex">
<div class="card flex-fill">
<div class="card-header  d-flex align-items-center justify-content-between">
<h4 class="card-title">Events List</h4>
<a href="events.php" class="fw-medium">View All</a>
</div>
<div class="card-body p-0">
<ul class="list-group list-group-flush">
<li class="list-group-item p-3">
<div class="d-flex align-items-center justify-content-between">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-lg flex-shrink-0 me-2">
<img src="assets/img/events/event-01.jpg" class="img-fluid" alt="img">
</a>
<div class="overflow-hidden">
<h6 class="mb-1"><a href="events.php">Parents, Teacher Meet</a>
</h6>
<p><i class="ti ti-calendar me-1"></i>15 July 2024</p>
</div>
</div>
<span class="badge badge-soft-danger d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Full Day</span>
</div>
</li>
<li class="list-group-item p-3">
<div class="d-flex align-items-center justify-content-between">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-lg flex-shrink-0 me-2">
<img src="assets/img/events/event-02.jpg" class="img-fluid" alt="img">
</a>
<div class="overflow-hidden">
<h6 class="mb-1"><a href="events.php">Farewell</a></h6>
<p><i class="ti ti-calendar me-1"></i>11 Mar 2024</p>
</div>
</div>
<span class="badge badge-soft-skyblue d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Half Day</span>
</div>
</li>
<li class="list-group-item p-3">
<div class="d-flex align-items-center justify-content-between">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-lg flex-shrink-0 me-2">
<img src="assets/img/events/event-03.jpg" class="img-fluid" alt="img">
</a>
<div class="overflow-hidden">
<h6 class="mb-1"><a href="events.php">Annual Day</a></h6>
<p><i class="ti ti-calendar me-1"></i>11 Mar 2024</p>
</div>
</div>
<span class="badge badge-soft-skyblue d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Half Day</span>
</div>
</li>
<li class="list-group-item p-3">
<div class="d-flex align-items-center justify-content-between">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-lg flex-shrink-0 me-2">
<img src="assets/img/events/event-04.jpg" class="img-fluid" alt="img">
</a>
<div class="overflow-hidden">
<h6 class="mb-1"><a href="events.php">Holi Celebration</a></h6>
<p><i class="ti ti-calendar me-1"></i>15 July 2024</p>
</div>
</div>
<span class="badge badge-soft-danger d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Full Day</span>
</div>
</li>
<li class="list-group-item p-3">
<div class="d-flex align-items-center justify-content-between">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-lg flex-shrink-0 me-2">
<img src="assets/img/events/event-05.jpg" class="img-fluid" alt="img">
</a>
<div class="overflow-hidden">
<h6 class="mb-1"><a href="events.php">Exam Result</a></h6>
<p><i class="ti ti-calendar me-1"></i>16 July 2024</p>
</div>
</div>
<span class="badge badge-soft-skyblue d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Half Day</span>
</div>
</li>
</ul>
</div>
</div>
</div>


<div class="col-xxl-8 col-xl-6 d-flex">
<div class="card flex-fill">
<div class="card-header d-flex align-items-center justify-content-between">
<h4 class="card-title">Statistics</h4>
<div class="dropdown">
<a href="javascript:void(0);" class="bg-white dropdown-toggle" data-bs-toggle="dropdown"><i class="ti ti-calendar me-2"></i>This Month
</a>
<ul class="dropdown-menu mt-2 p-3">
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
This Month
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
This Year
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Last Week
</a>
</li>
</ul>
</div>
</div>
<div class="card-body pb-0">
<div id="statistic_chart"></div>
</div>
</div>
</div>

</div>
<div class="row">

<div class="col-xxl-4 col-xl-6 d-flex">
<div class="card flex-fill">
<div class="card-header d-flex align-items-center justify-content-between">
<h4 class="card-title">Leave Status</h4>
<div class="dropdown">
<a href="javascript:void(0);" class="bg-white dropdown-toggle" data-bs-toggle="dropdown"><i class="ti ti-calendar me-2"></i>This Month
</a>
<ul class="dropdown-menu mt-2 p-3">
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
This Month
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
This Year
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Last Week
</a>
</li>
</ul>
</div>
</div>
<div class="card-body">
<div class="bg-light-300 d-sm-flex align-items-center justify-content-between p-3 mb-3">
<div class="d-flex align-items-center mb-2 mb-sm-0">
<div class="avatar avatar-lg bg-danger-transparent flex-shrink-0 me-2"><i class="ti ti-brand-socket-io"></i></div>
<div>
<h6 class="mb-1">Emergency Leave</h6>
<p>Date : 15 Jun 2024</p>
</div>
</div>
<span class="badge bg-skyblue d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Pending</span>
</div>
<div class="bg-light-300 d-sm-flex align-items-center justify-content-between p-3 mb-3">
<div class="d-flex align-items-center mb-2 mb-sm-0">
<div class="avatar avatar-lg bg-info-transparent flex-shrink-0 me-2"><i class="ti ti-medical-cross"></i></div>
<div>
<h6 class="mb-1">Medical Leave</h6>
<p>Date : 15 Jun 2024</p>
</div>
</div>
<span class="badge bg-success d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Approved</span>
</div>
<div class="bg-light-300 d-sm-flex align-items-center justify-content-between p-3 mb-3">
<div class="d-flex align-items-center mb-2 mb-sm-0">
<div class="avatar avatar-lg bg-info-transparent flex-shrink-0 me-2"><i class="ti ti-medical-cross"></i></div>
<div>
<h6 class="mb-1">Medical Leave</h6>
<p>Date : 16 Jun 2024</p>
</div>
</div>
<span class="badge bg-danger d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Declined</span>
</div>
<div class="bg-light-300 d-sm-flex align-items-center justify-content-between p-3 mb-0">
<div class="d-flex align-items-center mb-2 mb-sm-0">
<div class="avatar avatar-lg bg-danger-transparent flex-shrink-0 me-2"><i class="ti ti-brand-socket-io"></i></div>
<div>
<h6 class="mb-1">Fever</h6>
<p>Date : 16 Jun 2024</p>
</div>
</div>
<span class="badge bg-success d-inline-flex align-items-center"><i class="ti ti-circle-filled fs-5 me-1"></i>Approved</span>
</div>
</div>
</div>
</div>


<div class="col-xxl-4  col-xl-6 d-flex">
<div class="card flex-fill">
<div class="card-header d-flex align-items-center justify-content-between">
<h4 class="card-titile">Home Works</h4>
<div class="dropdown">
<a href="javascript:void(0);" class="bg-white dropdown-toggle" data-bs-toggle="dropdown"><i class="ti ti-book-2 me-2"></i>All Subject
</a>
<ul class="dropdown-menu mt-2 p-3">
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Physics
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Chemistry
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Maths
</a>
</li>
</ul>
</div>
</div>
<div class="card-body py-1">
<ul class="list-group list-group-flush">
<li class="list-group-item py-3 px-0">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-xl flex-shrink-0 me-2">
<img src="assets/img/home-work/home-work-01.jpg" alt="img">
</a>
<div class="overflow-hidden">
<p class="d-flex align-items-center text-info mb-1"><i class="ti ti-tag me-2"></i>Physics</p>
<h6 class="text-truncate mb-1"><a href="class-home-work.php">Write
about Theory of Pendulum</a></h6>
<div class="d-flex align-items-center flex-wrap">
<div class="d-flex align-items-center border-end me-1 pe-1">
<a href="teacher-details.php" class="avatar avatar-xs flex-shrink-0 me-2">
<img src="assets/img/teachers/teacher-01.jpg" class="rounded-circle" alt="teacher">
</a>
<p class="text-dark">Aaron</p>
</div>
<p>Due by : 16 Jun 2024</p>
</div>
</div>
</div>
</li>
<li class="list-group-item py-3 px-0">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-xl flex-shrink-0 me-2">
<img src="assets/img/home-work/home-work-02.jpg" alt="img">
</a>
<div class="overflow-hidden">
<p class="d-flex align-items-center text-success mb-1"><i class="ti ti-tag me-2"></i>Chemistry</p>
<h6 class="text-truncate mb-1"><a href="class-home-work.php">Chemistry
- Change of Elements</a></h6>
<div class="d-flex align-items-center flex-wrap">
<div class="d-flex align-items-center border-end me-1 pe-1">
<a href="teacher-details.php" class="avatar avatar-xs flex-shrink-0 me-2">
<img src="assets/img/teachers/teacher-01.jpg" class="rounded-circle" alt="teacher">
</a>
<p class="text-dark">Hellana</p>
</div>
<p>Due by : 16 Jun 2024</p>
</div>
</div>
</div>
</li>
<li class="list-group-item py-3 px-0">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-xl flex-shrink-0 me-2">
<img src="assets/img/home-work/home-work-03.jpg" alt="img">
</a>
<div class="overflow-hidden">
<p class="d-flex align-items-center text-danger mb-1"><i class="ti ti-tag me-2"></i>Maths</p>
<h6 class="text-truncate mb-1"><a href="class-home-work.php">Maths -
Problems to Solve Page 21</a></h6>
<div class="d-flex align-items-center flex-wrap">
<div class="d-flex align-items-center border-end me-1 pe-1">
<a href="teacher-details.php" class="avatar avatar-xs flex-shrink-0 me-2">
<img src="assets/img/teachers/teacher-01.jpg" class="rounded-circle" alt="teacher">
</a>
<p class="text-dark">Morgan</p>
</div>
<p>Due by : 21 Jun 2024</p>
</div>
</div>
</div>
</li>
<li class="list-group-item py-3 px-0">
<div class="d-flex align-items-center">
<a href="javascript:void(0);" class="avatar avatar-xl flex-shrink-0 me-2">
<img src="assets/img/home-work/home-work-04.jpg" alt="img">
</a>
<div class="overflow-hidden">
<p class="d-flex align-items-center text-skyblue mb-1"><i class="ti ti-tag me-2"></i>Engish</p>
<h6 class="text-truncate mb-1"><a href="class-home-work.php">English -
Vocabulary Introduction</a></h6>
<div class="d-flex align-items-center flex-wrap">
<div class="d-flex align-items-center border-end me-1 pe-1">
<a href="teacher-details.php" class="avatar avatar-xs flex-shrink-0 me-2">
<img src="assets/img/teachers/teacher-01.jpg" class="rounded-circle" alt="teacher">
</a>
<p class="text-dark">Daniel Josua</p>
</div>
<p>Due by : 21 Jun 2024</p>
</div>
</div>
</div>
</li>
</ul>
</div>
</div>
</div>


<div class="col-xxl-4 col-xl-12 d-flex">
<div class="card flex-fill">
<div class="card-header d-flex align-items-center justify-content-between">
<h4 class="card-titile">Fees Reminder</h4>
<a href="fees-assign.php" class="link-primary fw-medium">View All</a>
</div>
<div class="card-body py-1">
<div class="d-flex align-items-center justify-content-between py-3">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-info-transparent avatar avatar-lg me-2 rounded-circle flex-shrink-0">
<i class="ti ti-bus-stop fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Transport Fees</h6>
<p>$2500</p>
</div>
</div>
<div class="text-end">
<h6 class="mb-1">Last Date</h6>
<p>25 May 2024</p>
</div>
</div>
<div class="d-flex align-items-center justify-content-between py-3">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-success-transparent avatar avatar-lg me-2 rounded-circle flex-shrink-0">
<i class="ti ti-books fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Book Fees</h6>
<p>$2500</p>
</div>
</div>
<div class="text-end">
<h6 class="mb-1">Last Date</h6>
<p>25 May 2024</p>
</div>
</div>
<div class="d-flex align-items-center justify-content-between py-3">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-info-transparent avatar avatar-lg me-2 rounded-circle flex-shrink-0">
<i class="ti ti-report-money fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Exam Fees</h6>
<p>$2500</p>
</div>
</div>
<div class="text-end">
<h6 class="mb-1">Last Date</h6>
<p>25 May 2024</p>
</div>
</div>
<div class="d-flex align-items-center justify-content-between py-3">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-skyblue-transparent avatar avatar-lg me-2 rounded-circle flex-shrink-0">
<i class="ti ti-meat fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Mess Fees <span class="d-inline-flex align-items-center badge badge-soft-danger"><i class="ti ti-circle-filled me-1 fs-5"></i>Due</span></h6>
<p class="text-danger">$2500 + $150</p>
</div>
</div>
<div class="text-end">
<a href="#" class="btn btn-primary btn-sm">Pay now</a>
</div>
</div>
<div class="d-flex align-items-center justify-content-between py-3">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-danger-transparent avatar avatar-lg me-2 rounded-circle flex-shrink-0">
<i class="ti ti-report-money fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Hostel</h6>
<p>$2500</p>
</div>
</div>
<div class="text-end">
<h6 class="mb-1">Last Date</h6>
<p>25 May 2024</p>
</div>
</div>
</div>
</div>
</div>

</div>
<div class="row">

<div class="col-xxl-8 col-xl-7 d-flex">
<div class="card flex-fill">
<div class="card-header d-flex align-items-center justify-content-between flex-wrap pb-0">
<h4 class="card-title mb-3">Exam Result</h4>
<div class="d-flex align-items-center">
<div class="dropdown me-3 mb-3">
<a href="javascript:void(0);" class="bg-white dropdown-toggle" data-bs-toggle="dropdown"><i class="ti ti-calendar me-2"></i>All Classes
</a>
<ul class="dropdown-menu mt-2 p-3">
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
I
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
II
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
III
</a>
</li>
</ul>
</div>
<div class="dropdown mb-3">
<a href="javascript:void(0);" class="bg-white dropdown-toggle" data-bs-toggle="dropdown"><i class="ti ti-calendar me-2"></i>All Exams
</a>
<ul class="dropdown-menu mt-2 p-3">
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Quartely
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
Practical
</a>
</li>
<li>
<a href="javascript:void(0);" class="dropdown-item rounded-1">
1st Term
</a>
</li>
</ul>
</div>
</div>
</div>
<div class="card-body px-0">
<div class="custom-datatable-filter table-responsive">
<table class="table">
<thead class="thead-light">
<tr>
<th>ID</th>
<th>Name</th>
<th>Class </th>
<th>Section</th>
<th>Marks %</th>
<th>Exams</th>
<th>Status</th>
</tr>
</thead>
<tbody>
<tr>
<td>35013</td>
<td>
<div class="d-flex align-items-center">
<a href="student-details.php" class="avatar avatar-md"><img src="assets/img/students/student-01.jpg" class="img-fluid rounded-circle" alt="img"></a>
<div class="ms-2">
<p class="text-dark mb-0"><a href="student-details.php">Janet</a></p>
</div>
</div>
</td>
<td>III</td>
<td>A</td>
<td>89%</td>
<td>Quartely</td>
<td>
<span class="badge bg-success">Pass</span>
</td>
</tr>
<tr>
<td>35013</td>
<td>
<div class="d-flex align-items-center">
<a href="student-details.php" class="avatar avatar-md"><img src="assets/img/students/student-02.jpg" class="img-fluid rounded-circle" alt="img"></a>
<div class="ms-2">
<p class="text-dark mb-0"><a href="staff-details.php">Joann</a></p>
</div>
</div>
</td>
<td>IV</td>
<td>B</td>
<td>88%</td>
<td>Practical</td>
<td>
<span class="badge bg-success">Pass</span>
</td>
</tr>
<tr>
<td>35010</td>
<td>
<div class="d-flex align-items-center">
<a href="student-details.php" class="avatar avatar-md"><img src="assets/img/students/student-04.jpg" class="img-fluid rounded-circle" alt="img"></a>
<div class="ms-2">
<p class="text-dark mb-0"><a href="student-details.php">Gifford</a></p>
</div>
</div>
</td>
<td>I</td>
<td>B</td>
<td>21%</td>
<td>Mid Term</td>
<td>
<span class="badge bg-success">Pass</span>
</td>
</tr>
<tr>
<td>35009</td>
<td>
<div class="d-flex align-items-center">
<a href="student-details.php" class="avatar avatar-md"><img src="assets/img/students/student-05.jpg" class="img-fluid rounded-circle" alt="img"></a>
<div class="ms-2">
<p class="text-dark mb-0"><a href="student-details.php">Lisa</a></p>
</div>
</div>
</td>
<td>II</td>
<td>B</td>
<td>31%</td>
<td>Annual</td>
<td>
<span class="badge bg-danger">Fail</span>
</td>
</tr>
<tr>
<td>35015</td>
<td>
<div class="d-flex align-items-center">
<a href="student-details.php" class="avatar avatar-md"><img src="assets/img/students/student-08.jpg" class="img-fluid rounded-circle" alt="img"></a>
<div class="ms-2">
<p class="text-dark mb-0"><a href="student-details.php">Riana</a></p>
</div>
</div>
</td>
<td>III</td>
<td>A</td>
<td>89%</td>
<td>Quartely</td>
<td>
<span class="badge bg-success">Pass</span>
</td>
</tr>
<tr>
<td>35013</td>
<td>
<div class="d-flex align-items-center">
<a href="student-details.php" class="avatar avatar-md"><img src="assets/img/students/student-06.jpg" class="img-fluid rounded-circle" alt="img"></a>
<div class="ms-2">
<p class="text-dark mb-0"><a href="staff-details.php">Angelo </a></p>
</div>
</div>
</td>
<td>IV</td>
<td>B</td>
<td>88%</td>
<td>Practical</td>
<td>
<span class="badge bg-danger">Fail</span>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>


<div class="col-xxl-4 col-xl-5 d-flex">
<div class="card flex-fill">
<div class="card-header  d-flex align-items-center justify-content-between">
<h4 class="card-title">Notice Board</h4>
<a href="notice-board.php" class="fw-medium">View All</a>
</div>
<div class="card-body">
<div class="notice-widget">
<div class="d-flex align-items-center justify-content-between mb-4">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-primary-transparent avatar avatar-md me-2 rounded-circle flex-shrink-0">
<i class="ti ti-books fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">New Syllabus Instructions</h6>
<p><i class="ti ti-calendar me-2"></i>Added on : 11 Mar 2024</p>
</div>
</div>
<a href="notice-board.php"><i class="ti ti-chevron-right fs-16"></i></a>
</div>
<div class="d-flex align-items-center justify-content-between mb-4">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-success-transparent avatar avatar-md me-2 rounded-circle flex-shrink-0">
<i class="ti ti-note fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">World Environment Day Program.....!!!
</h6>
<p><i class="ti ti-calendar me-2"></i>Added on : 21 Apr 2024</p>
</div>
</div>
<a href="notice-board.php"><i class="ti ti-chevron-right fs-16"></i></a>
</div>
<div class="d-flex align-items-center justify-content-between mb-4">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-danger-transparent avatar avatar-md me-2 rounded-circle flex-shrink-0">
<i class="ti ti-bell-check fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Exam Preparation Notification!</h6>
<p><i class="ti ti-calendar me-2"></i>Added on : 13 Mar 2024</p>
</div>
</div>
<a href="notice-board.php"><i class="ti ti-chevron-right fs-16"></i></a>
</div>
<div class="d-flex align-items-center justify-content-between mb-4">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-skyblue-transparent avatar avatar-md me-2 rounded-circle flex-shrink-0">
<i class="ti ti-notes fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Online Classes Preparation</h6>
<p><i class="ti ti-calendar me-2"></i>Added on : 24 May 2024</p>
</div>
</div>
<a href="notice-board.php"><i class="ti ti-chevron-right fs-16"></i></a>
</div>
<div class="d-flex align-items-center justify-content-between mb-4">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-warning-transparent avatar avatar-md me-2 rounded-circle flex-shrink-0">
<i class="ti ti-package fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">Exam Time Table Release</h6>
<p><i class="ti ti-calendar me-2"></i>Added on : 24 May 2024</p>
</div>
</div>
<a href="notice-board.php"><i class="ti ti-chevron-right fs-16"></i></a>
</div>
<div class="d-flex align-items-center justify-content-between mb-0">
<div class="d-flex align-items-center overflow-hidden me-2">
<span class="bg-danger-transparent avatar avatar-md me-2 rounded-circle flex-shrink-0">
<i class="ti ti-bell-check fs-16"></i>
</span>
<div class="overflow-hidden">
<h6 class="text-truncate mb-1">English Exam Preparation</h6>
<p><i class="ti ti-calendar me-2"></i>Added on : 23 Mar 2024</p>
</div>
</div>
<a href="notice-board.php"><i class="ti ti-chevron-right fs-16"></i></a>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>


<div class="modal fade" id="edit_parent">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">Edit Parent</h4>
<button type="button" class="btn-close custom-btn-close" data-bs-dismiss="modal" aria-label="Close">
<i class="ti ti-x"></i>
</button>
</div>
<form action="parents.php">
<div class="modal-body">
<div class="row">
<div class="col-md-12">
<div class="d-flex align-items-center upload-pic flex-wrap row-gap-3 mb-3">
<div class="d-flex align-items-center justify-content-center avatar avatar-xxl border border-dashed me-2 flex-shrink-0 text-dark frames">
<i class="ti ti-photo-plus fs-16"></i>
</div>
<div class="profile-upload">
<div class="profile-uploader d-flex align-items-center">
<div class="drag-upload-btn mb-3">
Upload
<input type="file" class="form-control image-sign" multiple>
</div>
<a href="javascript:void(0);" class="btn btn-primary mb-3">Remove</a>
</div>
<p>Upload image size 4MB, Format JPG, PNG, SVG</p>
</div>
</div>
<div class="mb-3">
<label class="form-label">Name</label>
<input type="text" class="form-control" placeholder="Enter Name" value="Thomas">
</div>
<div class="mb-3">
<label class="form-label">Phone Number</label>
<input type="text" class="form-control" placeholder="Enter Phone Number" value="+1 65738 58937">
</div>
<div class="mb-3">
<label class="form-label">Email Address</label>
<input type="text" class="form-control" placeholder="Enter Email Address" value="thomas@example.com">
</div>
<div class="mb-0">
<label class="form-label">Child</label>
<select class="select" multiple>
<option selected>Janet</option>
<option selected>Joann</option>
<option>Kathleen</option>
<option>Gifford</option>
</select>
</div>
</div>
</div>
</div>
<div class="modal-footer">
<a href="#" class="btn btn-light me-2" data-bs-dismiss="modal">Cancel</a>
<button type="submit" class="btn btn-primary">Save Changes</button>
</div>
</form>
</div>
</div>
</div>

</div>



<script src="assets/js/jquery-3.7.1.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/bootstrap.bundle.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/moment.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>
<script src="assets/plugins/daterangepicker/daterangepicker.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>
<script src="assets/js/bootstrap-datetimepicker.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/jquery.dataTables.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>
<script src="assets/js/dataTables.bootstrap5.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/feather.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/jquery.slimscroll.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/plugins/select2/js/select2.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/theme-script.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/js/script.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script> 
<script src="assets/js/owl.carousel.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>

<script src="assets/plugins/apexchart/apexcharts.min.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>
<script src="assets/plugins/apexchart/chart-data.js" type="53dd04b530fdf62c5bb3c200-text/javascript"></script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="53dd04b530fdf62c5bb3c200-|49" defer></script></body>
</html>